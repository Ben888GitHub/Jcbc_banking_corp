var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'zwenyantoe',
applicationName: 'myapp',
appUid: 'glJh9sC80m5MjnCSzb',
tenantUid: '62WS4srD6yVmVxyPRV',
deploymentUid: 'd346bab6-b17d-40e3-af65-d9951199f384',
serviceName: 'cp3405',
stageName: 'dev',
pluginVersion: '3.2.5'})
const handlerWrapperArgs = { functionName: 'cp3405-dev-check_otp', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.check_otp, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
