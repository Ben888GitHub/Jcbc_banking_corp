var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'zwenyantoe',
applicationName: 'myapp',
appUid: 'glJh9sC80m5MjnCSzb',
tenantUid: '62WS4srD6yVmVxyPRV',
deploymentUid: '70c6531d-498b-420c-a024-32bcd1a1a19d',
serviceName: 'cp3405',
stageName: 'dev',
pluginVersion: '3.2.5'})
const handlerWrapperArgs = { functionName: 'cp3405-dev-sendinvoice', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.sendinvoice, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
