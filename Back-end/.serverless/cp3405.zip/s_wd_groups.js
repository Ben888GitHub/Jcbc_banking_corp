var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'hungnguy',
applicationName: 'cp3405',
appUid: 'y07B3cl56f3F6LyMtF',
tenantUid: 'Xpvz7QQWsM4KWk1S1d',
deploymentUid: '9a6a73f8-bf78-4cfa-8a41-4f4f7b45dec8',
serviceName: 'cp3405',
stageName: 'dev',
pluginVersion: '3.2.5'})
const handlerWrapperArgs = { functionName: 'cp3405-dev-wd_groups', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.cp3405, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
