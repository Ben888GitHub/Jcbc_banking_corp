var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'zwenyantoe',
applicationName: 'myapp',
appUid: 'glJh9sC80m5MjnCSzb',
tenantUid: '62WS4srD6yVmVxyPRV',
deploymentUid: 'fc6ef170-45c3-433b-8462-bcb89b9187a9',
serviceName: 'cp3405',
stageName: 'dev',
pluginVersion: '3.2.5'})
const handlerWrapperArgs = { functionName: 'cp3405-dev-wd_groups', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.cp3405, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
