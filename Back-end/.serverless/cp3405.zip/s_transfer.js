var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'zwenyantoe',
applicationName: 'myapp',
appUid: 'glJh9sC80m5MjnCSzb',
tenantUid: '62WS4srD6yVmVxyPRV',
deploymentUid: '6e170c57-9ebc-496a-bea3-ecf2c2847243',
serviceName: 'cp3405',
stageName: 'dev',
pluginVersion: '3.2.5'})
const handlerWrapperArgs = { functionName: 'cp3405-dev-transfer', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.transfer, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
