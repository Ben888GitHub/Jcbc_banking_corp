var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'zwenyantoe',
applicationName: 'myapp',
appUid: 'glJh9sC80m5MjnCSzb',
tenantUid: '62WS4srD6yVmVxyPRV',
deploymentUid: 'a2c7ae53-8317-4665-a510-e59092ebd9af',
serviceName: 'cp3405',
stageName: 'dev',
pluginVersion: '3.2.5'})
const handlerWrapperArgs = { functionName: 'cp3405-dev-transfer', timeout: 6}
try {
  const userHandler = require('./handler.js')
  module.exports.handler = serverlessSDK.handler(userHandler.transfer, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
